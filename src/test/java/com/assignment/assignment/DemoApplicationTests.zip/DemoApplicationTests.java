package com.assignment.assignment;

import java.io.IOException;
import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.assignment.assignment.User;
import com.assignment.assignment.UserRepository;

public class DemoApplicationTests extends AbstractTest {

	@Override
	@Before
	public void setUp() {
		super.setUp();
	}

	@Test
	public void getUsers() throws Exception {
		UserRepository repository = mock(UserRepository.class);
		List<User> expected = ArrayList<>();
		expected.add(new User("A", 1000.00));
		when(repository.findAll()).thenReturn(expected);

		String uri = "/users";

		MvcResult mvcResult = mvc.perform(
			MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE)
		).andReturn();
		
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);

		String content = mvcResult.getResponse().getContentAsString();
		
		TypeReference<HashMap<String, List<User>>> typeRef =
			new TypeReference<HashMap<String, List<User>>>() {};

		ObjectMapper objectMapper = new ObjectMapper();
		HashMap<String, List<User>> results = objectMapper.readValue(
			content,
			typeRef
		);
		assertTrue(results.get("results").size() == 1);
	}

}
